import React, { useState } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import CalculatorButton from './CalculatorButton';

const windowWidth = Dimensions.get('window').width;

const App = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handleButtonPress = (value) => {
    setInput(input + value);
  };

  const handleCalculate = () => {
    try {
      const calculatedResult = eval(input);
      setResult(calculatedResult.toString());
    } catch (error) {
      setResult('Error');
    }
  };

  const handleClear = () => {
    setInput('');
    setResult('');
  };

  return (
    <View style={styles.container}>
      <View style={styles.resultContainer}>
        <Text style={styles.resultText}>{input}</Text>
      </View>
      <View style={styles.buttonsContainer}>
        <View style={styles.row}>
          <CalculatorButton title="7" onPress={() => handleButtonPress('7')} />
          <CalculatorButton title="8" onPress={() => handleButtonPress('8')} />
          <CalculatorButton title="9" onPress={() => handleButtonPress('9')} />
          <CalculatorButton title="/" onPress={() => handleButtonPress('/')} />
        </View>
        <View style={styles.row}>
          <CalculatorButton title="4" onPress={() => handleButtonPress('4')} />
          <CalculatorButton title="5" onPress={() => handleButtonPress('5')} />
          <CalculatorButton title="6" onPress={() => handleButtonPress('6')} />
          <CalculatorButton title="*" onPress={() => handleButtonPress('*')} />
        </View>
        <View style={styles.row}>
          <CalculatorButton title="1" onPress={() => handleButtonPress('1')} />
          <CalculatorButton title="2" onPress={() => handleButtonPress('2')} />
          <CalculatorButton title="3" onPress={() => handleButtonPress('3')} />
          <CalculatorButton title="-" onPress={() => handleButtonPress('-')} />
        </View>
        <View style={styles.row}>
          <CalculatorButton title="C" color="orange" onPress={handleClear} />
          <CalculatorButton title="0" onPress={() => handleButtonPress('0')} />
          <CalculatorButton title="=" color="green" onPress={handleCalculate} />
          <CalculatorButton title="+" onPress={() => handleButtonPress('+')} />
        </View>
      </View>
      <View style={styles.resultContainer}>
        <Text style={styles.resultText}>{result}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  resultContainer: {
    marginBottom: 20,
  },
  resultText: {
    fontSize: 40,
    fontWeight: 'bold',
  },
  buttonsContainer: {
    width: windowWidth,
    paddingHorizontal: 10,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
});

export default App;
