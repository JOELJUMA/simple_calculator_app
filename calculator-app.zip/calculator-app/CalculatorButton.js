import React from 'react';
import { TouchableOpacity, Text, StyleSheet, Dimensions } from 'react-native';

const windowWidth = Dimensions.get('window').width;

const CalculatorButton = ({ onPress, title, color }) => (
  <TouchableOpacity
    style={[styles.button, { backgroundColor: color || '#f0f0f0' }]}
    onPress={onPress}
  >
    <Text style={styles.buttonText}>{title}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  button: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#ccc',
    width: windowWidth / 4,
    height: windowWidth / 4,
  },
  buttonText: {
    fontSize: 24,
  },
});

export default CalculatorButton;
